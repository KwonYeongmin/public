#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


//����4


int main()
{
	int target;
	scanf("%d",&target);
	int ary[5] = {1,2,3,4,5};
	int ans[3][2];
	int i, j,count=0;

	for (i = 0; i < 5;i++) 
	{
		for (j = 0; j < 5; j++)
		{
			if (ary[i] + ary[j] == target) 
			{
				ans[count][0] = i;
				ans[count][1] = j;

				count++;
			}
		}
	}
	for (int k = 0; k < count; k++)
	{			
		printf("{ %d %d } ", ans[k][0], ans[k][1]);	
	}

	return 0;
}



