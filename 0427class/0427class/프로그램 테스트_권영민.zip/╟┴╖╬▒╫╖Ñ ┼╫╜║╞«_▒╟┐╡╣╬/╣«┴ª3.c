#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


//����3


int main()
{
	int num;
	int count = 0;
	int num2[50];
	printf("��� �Է� : ");
	scanf("%d",&num);
	
	while(num > 0)
	{
		if ((num % 2) == 1) { num2[count] = 1; }
		else if ((num % 2) == 0){ num2[count] = 0; }
		num = num / 2;
		count++;		
	}

	for (int j = (count-1); j >=0; j-- ) 
	{
		printf("%d ", num2[j]);
	}
	
	return 0;
}






