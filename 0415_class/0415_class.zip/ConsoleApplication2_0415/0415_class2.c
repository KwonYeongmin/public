﻿
#include <stdio.h>

int main()
{
	//문제 7

	for (int j = 5; j <= 19; j =j+3)
	{
		for (int i = 1; i <= 9; i=+3)
		{
			
			for (int a = 0; a <= 2; a++)
			{
				printf("%d X %d = %d \n", j + a, i + a, (j + a) * (i + a));

				
			}
			printf(" -------------------------------------------------- \n");
		}
		
		
	}
	
		
	


	return 0;
}

